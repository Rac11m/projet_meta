package ga;

public class Couple {
    protected int[][] parent1;
    protected int[][] parent2;

    public Couple(int[][] parent1, int[][] parent2) {
        this.parent1 = parent1;
        this.parent2 = parent2;
    }
}
