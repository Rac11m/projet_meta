package ga;

public class Children {
    int[][] child1;
    int[][] child2;

    public Children(int[][] child1, int[][] child2) {
        this.child1 = child1;
        this.child2 = child2;
    }
}
